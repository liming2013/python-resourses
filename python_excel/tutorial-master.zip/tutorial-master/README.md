This repo is the home of an effort to turn the orignal tutorial covering [xlrd][1], [xlwt][2] and [xlutils][3] into a [Sphinx][4] project.

It is currently stalled and likely always will be. In the meantime, here's a link to a PDF rendering of the original Open Office document: 

https://github.com/python-excel/tutorial/raw/master/python-excel.pdf

[1]: https://github.com/python-excel/xlrd
[2]: https://github.com/python-excel/xlwt
[3]: https://github.com/python-excel/xlutils
[4]: http://sphinx-doc.org/

